
// Simulated data
let products = [];
let totalSales = 0;

// Functions for Inventory Management
function addProduct() {
    const productName = prompt("Enter product name:");
    if (productName) {
        products.push(productName);
        updateProductList();
    }
}

function updateProductList() {
    const productList = document.getElementById("product-list");
    productList.innerHTML = "";
    products.forEach((product, index) => {
        const li = document.createElement("li");
        li.textContent = product;
        li.onclick = () => removeProduct(index);
        productList.appendChild(li);
    });
    document.getElementById("total-products").textContent = products.length;
}

function removeProduct(index) {
    products.splice(index, 1);
    updateProductList();
}

// Functions for Sales
function recordSale() {
    const saleAmount = parseFloat(prompt("Enter sale amount:"));
    if (!isNaN(saleAmount)) {
        totalSales += saleAmount;
        document.getElementById("total-sales").textContent = `$${totalSales.toFixed(2)}`;
        const salesLog = document.getElementById("sales-log");
        const saleEntry = document.createElement("div");
        saleEntry.textContent = `Sale recorded: $${saleAmount.toFixed(2)}`;
        salesLog.appendChild(saleEntry);
    }
}
